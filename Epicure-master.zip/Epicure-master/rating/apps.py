from django.apps import AppConfig


class RatingConfig(AppConfig):
    name = 'rating'
